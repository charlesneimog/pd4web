from .fftw3 import downloadAndBuild_FFTW3





DYNAMIC_LIBRARIES = {
    "fftw3": downloadAndBuild_FFTW3,






        }



